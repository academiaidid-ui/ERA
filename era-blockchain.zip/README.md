# ERA Blockchain

Blockchain setup using Cosmos SDK.
