
# Whitepaper: ERA Blockchain

## Judul
**ERA Blockchain: Era Baru Aset Digital dengan Suplai Terbatas**

## Ringkasan Eksekutif
ERA adalah blockchain mandiri berbasis Cosmos SDK dengan mata uang digital asli bernama ERA. Total suplai dibatasi hanya 20 juta coin, menjadikannya aset langka dan ideal untuk ekosistem ekonomi yang transparan dan efisien.

## Latar Belakang
Di tengah membanjirnya token-token yang dibuat tanpa batasan suplai, ERA hadir dengan pendekatan berbeda: fixed supply, blockchain sendiri, dan fokus pada nilai jangka panjang. Dengan struktur blockchain mandiri, ERA tidak bergantung pada chain lain seperti Ethereum.

## Tujuan
- Menciptakan sistem keuangan terbuka berbasis coin langka
- Menyediakan platform untuk transaksi cepat dan biaya rendah
- Menjadi dasar ekosistem terdesentralisasi berbasis ERA Coin

## Spesifikasi Teknis
- Konsensus: Tendermint BFT (PoS)
- Total Suplai: 20.000.000 ERA (tetap)
- Block Time: ±5 detik
- Bahasa Pemrograman: Golang
- Framework: Cosmos SDK
- Validator Minimum: 1 (bisa bertambah)

## Distribusi
- Developer Genesis Wallet: 20.000.000 ERA
  - Distribusi lebih lanjut ditentukan melalui governance atau smart contract

## Kegunaan Coin ERA
- Medium of exchange dalam ekosistem
- Biaya transaksi
- Mekanisme reward dalam dApp atau game
- Aset investasi dan penyimpanan nilai

## Roadmap
- Q3 2025: Testnet ERA dan audit kode
- Q4 2025: Mainnet & komunitas node
- Q1 2026: Listing DEX & integrasi wallet

## Penutup
ERA bukan sekadar coin, melainkan platform yang lahir dari kebutuhan akan ekosistem digital terbatas, adil, dan efisien. Dengan suplai tetap dan chain mandiri, ERA menawarkan solusi masa depan berbasis kelangkaan dan transparansi.
