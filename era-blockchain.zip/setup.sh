
#!/bin/bash
# Blockchain ERA setup script using Cosmos SDK

echo "Installing dependencies..."
sudo apt update && sudo apt install build-essential git curl jq make gcc -y

echo "Installing Go..."
wget https://go.dev/dl/go1.20.5.linux-amd64.tar.gz
sudo tar -C /usr/local -xzf go1.20.5.linux-amd64.tar.gz
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
source ~/.bashrc

echo "Installing Starport..."
curl https://get.starport.network/starport! | bash

echo "Scaffolding chain ERA..."
starport scaffold chain github.com/username/era --address-prefix era
cd era

echo "Changing coin name to ERA..."
sed -i 's/stake/era/g' config.yml

echo "Ready to run: starport chain serve"
